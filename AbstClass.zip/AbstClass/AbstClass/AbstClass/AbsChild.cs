﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AbstClass
{
    
    class AbsChild:AbsParent
    {
        public override void Mul(int x, int y)
        {
            Console.WriteLine(x * y);
        }
        public override void Div(int x, int y)
        {
            Console.WriteLine(x / y);
        }
        static void Main()
        {
            AbsChild c = new AbsChild();
            c.Add(100, 100);
            c.Sub(100, 10);
            c.Mul(100, 100);
            c.Div(100, 100);
            Console.ReadLine();
        }
    }
}
