﻿using System;

namespace AbstClass
{
    class Program
    {
        
    }
}
