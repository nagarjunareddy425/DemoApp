﻿using Newtonsoft.Json.Linq;
using System;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DemoApp
{
    public partial class CRUDWithJSOn : Form
    {
        string jsonFile = @"C:\Users\nag25\Downloads\DemoApp (1)\DemoApp\DemoApp\user.json";

        public CRUDWithJSOn()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            GetCustomerDetails();
        }

        private void GetCustomerDetails()
        {
            var json = File.ReadAllText(jsonFile);
            try
            {
                var jObject = JObject.Parse(json);

                if (jObject != null)
                {
                    txtCustomerID.Text = jObject["customerid"].ToString();
                    txtCustomerName.Text = jObject["customername"].ToString();
                    txtPhoneNumber.Text = jObject["phoneNumber"].ToString();
                    
                    JArray ordersArrary = (JArray)jObject["orders"];
                    gridOrders.DataSource = ordersArrary;

                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        private async Task AddOrder()
        {            
            var orderID = txtOrderID.Text;
            var orderName = txtOrderName.Text;

            var orderDetails = "{ 'orderid': " + orderID + ",  'ordername': '" + orderName + "'}";
            try
            {
                var json = File.ReadAllText(jsonFile);
                var jsonObj = JObject.Parse(json);
                var ordersArrary = jsonObj.GetValue("orders") as JArray;
                var newOrder = JObject.Parse(orderDetails);
                ordersArrary.Add(newOrder);

                jsonObj["orders"] = ordersArrary;

                string newJsonResult = Newtonsoft.Json.JsonConvert.SerializeObject(jsonObj,
                                       Newtonsoft.Json.Formatting.Indented);
                File.WriteAllText(jsonFile, newJsonResult);

                MessageBox.Show("Order added successfully..!!");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Add Error : " + ex.Message.ToString());
            }
        }

        private async Task UpdateOrder()
        {
            string json = File.ReadAllText(jsonFile);

            try
            {
                var jObject = JObject.Parse(json);
                JArray ordersArrary = (JArray)jObject["orders"];

                var orderId = Convert.ToInt64(txtOrderID.Text);

                if (orderId > 0)
                {
                    var orderName = txtOrderName.Text;

                    foreach (var order in ordersArrary.Where(obj => obj["orderid"].Value<int>() == orderId))
                    {
                        order["ordername"] = !string.IsNullOrEmpty(orderName) ? orderName : "";
                    }

                    jObject["orders"] = ordersArrary;
                    string output = Newtonsoft.Json.JsonConvert.SerializeObject(jObject, Newtonsoft.Json.Formatting.Indented);
                    File.WriteAllText(jsonFile, output);

                    MessageBox.Show("Order updated successfully..!!");
                }
                else
                {
                    Console.Write("Invalid Order ID, Try Again!");
                }
            }
            catch (Exception ex)
            {

                Console.WriteLine("Update Error : " + ex.Message.ToString());
            }
        }

        private async Task DeleteOrder()
        {
            var json = File.ReadAllText(jsonFile);
            try
            {
                var jObject = JObject.Parse(json);
                JArray ordersArrary = (JArray)jObject["orders"];
                var orderId = Convert.ToInt32(txtOrderID.Text);

                if (orderId > 0)
                {
                    var orderName = string.Empty;
                    var orderToDeleted = ordersArrary.FirstOrDefault(obj => obj["orderid"].Value<int>() == orderId);

                    ordersArrary.Remove(orderToDeleted);

                    string output = Newtonsoft.Json.JsonConvert.SerializeObject(jObject, Newtonsoft.Json.Formatting.Indented);
                    File.WriteAllText(jsonFile, output);

                    MessageBox.Show("Order deleted successfully..!!");
                }
                else
                {
                    Console.Write("Invalid Order ID, Try Again!");
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        private async void btnAdd_ClickAsync(object sender, EventArgs e)
        {
            await AddOrder();
        }

        private async void btnUpdate_Click(object sender, EventArgs e)
        {
            await UpdateOrder();
        }

        private async void btnDelete_Click(object sender, EventArgs e)
        {
            await DeleteOrder();
        }
    }
}
