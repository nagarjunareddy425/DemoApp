﻿using Libraries;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoApp
{
    public class Order: Product
    {
        public int orderId;
        public Order()
        {
            productPrice = 222;
            verifyThis = "Verified";
        }
    }
}
