﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Serialization;

namespace DemoApp
{
    public partial class Serialization : Form
    {
        public string jsonData;
        public Serialization()
        {
            InitializeComponent();
        }

        private void btnSerialize_Click(object sender, EventArgs e)
        {
            SerializeThisClass serializeObj = new SerializeThisClass()
            {                
                Description = "Serialize/Deserialize into json type"
            };
            if (radioButtonJSON.Checked)
            {
                serializeObj.SerializationType = "JSon";
                // Convert object to JOSN string format  
                jsonData = JsonConvert.SerializeObject(serializeObj);
                MessageBox.Show(jsonData);
            }
            else
            {
                serializeObj.SerializationType = "XML";
                var serializer = new XmlSerializer(serializeObj.GetType());
                StringBuilder result = new StringBuilder();
                using (var writer = XmlWriter.Create("serializeClass.xml"))
                {
                    serializer.Serialize(writer, serializeObj);
                }
            }
        }

        private void btnDeserialize_Click(object sender, EventArgs e)
        {
            if (radioButtonJSON.Checked)
            {
                SerializeThisClass bsObj = JsonConvert.DeserializeObject<SerializeThisClass>(jsonData);
            }
            else
            {
                var serializer = new XmlSerializer(typeof(SerializeThisClass));
                using (var reader = XmlReader.Create("serializeClass.xml"))
                {
                    var deserializedData = (SerializeThisClass)serializer.Deserialize(reader);
                }
            }
        }
    }

    public class SerializeThisClass
    {
        public string SerializationType { get; set; }
        public string Description { get; set; }
    }
}
