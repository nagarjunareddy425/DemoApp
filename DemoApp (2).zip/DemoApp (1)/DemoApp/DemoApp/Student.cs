﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoApp
{
    public class Student 
    {
        //Properties/Variables
        public const int cid = 100;

        public long id;
        public string name;
        public double fee;
        public bool isActive;

        public string explainThis;

        //Local variables, Global variables.
        //Constructors

        public Student()
        {

        }
        public Student(int id, string name)
        {
            this.id = id;
            this.name = name;
        }
        public Student(int pid, string pname, double pfee, bool pisActive, string explainThis)
        {
            id = pid;
            name = pname;
            fee = pfee;
            isActive =pisActive;

            this.explainThis = explainThis;
        }

        public virtual int Meth1()
        {
            return 1;
        }       

        public int Meth1(int x)
        {
            return 2;
        }
    }

    public class Student1 : Student
    {
        public Student1() { }
        public override int Meth1()
        {
            return 5;
        }
    }

    public class ChildStudent: Student1 
    {        
        public new int Meth1()
        {
            return 10;
        }
    }

    public class Employee
    {

    }

    public class HRE: Employee
    {

    }

    public class ITE : Employee
    {

    }


    public class Area
    {
        public double CalculateArea(int l, int b)
        {
            return 1 / 2 * l * b;
        }

        public double CalculateArea(int r)
        {
            return r * r;
        }
    }
}
