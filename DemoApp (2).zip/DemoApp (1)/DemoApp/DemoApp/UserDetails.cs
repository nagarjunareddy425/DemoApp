﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DemoApp
{
    public partial class UserDetails : Form
    {
        string connString = "Server=NAG;Database=Demo;Trusted_Connection=True;";
        SqlConnection conn = new SqlConnection();

        public UserDetails()
        {
            
            InitializeComponent();
        }

        private void UserDetails_Load(object sender, EventArgs e)
        {
            BindUserDetailsToGrid();
        }

        private void btnAddUser_Click(object sender, EventArgs e)
        {
            try
            {
                string sql = "Insert into UserDetails values('" + txtUserName.Text + "', '" + txtDepartment.Text + "', '" + Guid.NewGuid() + "','" + Convert.ToDateTime(dateTimePicker1.Text) + "'," + Convert.ToInt64(txtSalary.Text) + ")";
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandText = sql;
                conn.Open();
                var affectedRows = cmd.ExecuteNonQuery();
                if (affectedRows > 0)
                {
                    MessageBox.Show("User added successfully..!!");
                    conn.Close();
                    BindUserDetailsToGrid();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                
                conn.Close();

            }
            }

        public void BindUserDetailsToGrid(string sql = null)
        {
           
            conn.ConnectionString = connString;
            if (string.IsNullOrEmpty(sql))
            {
                sql = "select * from UserDetails";
            }
            SqlDataAdapter myAdapter = new SqlDataAdapter(sql, conn);

            DataSet myDataSet = new DataSet("UserDetails");
            myAdapter.Fill(myDataSet, "UserDetails");            
            dataGridView1.DataSource = myDataSet.Tables[0];
        }

        private void button1_Click(object sender, EventArgs e)
        {
            BindUserDetailsToGrid("select * from dbo.UserDetails Where Department = '" + txtDepartment.Text + "'");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            BindUserDetailsToGrid("SELECT * FROM  UserDetails WHERE DATEDIFF(day, DOJ, getdate()) between 0 and 30");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            BindUserDetailsToGrid("Select * from UserDetails order by Name desc");
        }

        private void btnSortByDate_Click(object sender, EventArgs e)
        {
            BindUserDetailsToGrid("Select * from UserDetails order by DOJ desc");
        }

        private void btnRefreshGrid_Click(object sender, EventArgs e)
        {
            BindUserDetailsToGrid();
        }

        private void btnSalary_Click(object sender, EventArgs e)
        {
            BindUserDetailsToGrid("Select * from UserDetails Where salary > 5000");
        }
    }
}
