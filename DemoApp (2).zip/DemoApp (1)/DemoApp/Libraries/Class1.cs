﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Libraries
{
    public class Class1
    {
       public Class1()
        {
            Product prod = new Product();
        }

        /*
         * 1.      Write program that will perform below tasks. If no valid input provide, return proper message.
o   Accept number as a string and convert to integer.
o   Accept value as a string and convert to predefined Enums.
o   Accept date as a string and convert to date and return in dd-MMM-yyyy format .

        2.      Write program that load list of class User (Name, Department, DOJ, Passcode)
o   User should be able to add new user. Name should not be duplicated --Done
o   Generate random unique number and assign as passcode --Done
o   Get all users for the one department --Done
o   Get all users whose salary is more than 5000 --Done
o   Get all user whose DOJ is in last 30 days -- Done
o   Sort list by name and return --Done
o   Sort list by DOJ descending and return --Done

        3.      Write program to create, write, update, read and delete text file. All operations should be asynchronous.

4.      Write program to encrypt, decrypt, encode, decode string. --Done
5.      Write program to serialize and de-serialize class object to JSON and XML.--Done

        6.      Write program to exhibit best suited scenario for abstract class and interface.
7.      Write program to CRUD using any one local storage (e.g. SQLite, Json, Xml etc…) . All operations should be asynchronous. --Done
8.      Write program that will take method as a parameter and execute provided method using Func delegate.

        9.      Write program to invoke REST HttpRequst with methods(e.g. GET, POST , PUT , DELETE) – APIs can be provided or you can create your own sample API.
10.   Write program to expose any of the above task as library(.dll) and invoke methods using reflection in console project.
 
Notes:
1.      You can use any project type (e.g. Console App, Windows/WPF App, Web App)
2.      Project name should reflect task
3.      Variable name should reflect actual task performing
4.      Try to expose smaller feature as library and use in other application
5.      Try to use OOPs concept as much as you can
6.      Proper error handling must be done
         * */
    }
}
