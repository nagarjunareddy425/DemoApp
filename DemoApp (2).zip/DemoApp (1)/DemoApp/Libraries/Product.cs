﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Libraries
{
    public class Product
    {
        public int productId;
        private string productName;
        protected internal int productPrice;
        internal int quantity;
        protected internal string verifyThis;
    }

    public enum weekdays
    {
        sunday, 
        monday, 
        tuesday,
        wednesday,
        thursday,
        friday,
        saturday
    }
}
