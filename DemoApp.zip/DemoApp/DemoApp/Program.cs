using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please enter any string: ");
            string input = Console.ReadLine();
            if (string.IsNullOrEmpty(input))
            {
                Console.WriteLine("Please enter any value to proceed:");
                input = Console.ReadLine();
            }

            //ConvertStringToInt(input);
            //StringToEnum(input);
            ConvertStringToDate(input);
        }

        private static void ConvertStringToDate(string input)
        {
            var dt = Convert.ToDateTime(input).ToString("dd/MMM/yyyy");
            Console.WriteLine("new date value after convertion: " + dt);
            Console.WriteLine("Press any key to exit.");
            Console.ReadKey();
        }

        public static void ConvertStringToInt(string input)
        {
            int numVal = 0;
            
            try
            {                
                numVal = Convert.ToInt32(input);
                Console.WriteLine("entered number is: {0}", numVal);
            }
            catch (FormatException e)
            {
                Console.WriteLine("Input string is not a sequence of digits.");
            }
            catch (OverflowException e)
            {
                Console.WriteLine("The number cannot fit in an Int32.");
            }
            Console.WriteLine("Press any key to exit.");
            Console.ReadKey();
        }

        public static void StringToEnum(string input)
        {
            
            if(Enum.TryParse(input, out StatusEnum myStatus))
            {
                Console.WriteLine("Entered string is found in the predefined enum and the value is : " + myStatus);
            }
            else
            {
                Console.WriteLine("Could not find this value in enum, enum values are  : " + StatusEnum.Monday+","+StatusEnum.Friday);
            }
            Console.WriteLine("Press any key to exit.");
            Console.ReadKey();
        }
    }

    public enum StatusEnum
    {
        Monday,
        Friday
    }
}