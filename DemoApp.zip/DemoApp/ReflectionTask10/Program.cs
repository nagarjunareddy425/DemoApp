using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace ReflectionTask10
{
    class Program
    {
        static void Main(string[] args)
        {            
            Console.Write("Enter the Name:");
            string typName = Console.ReadLine();

            Assembly asm = Assembly.Load(typName);
            DispalyAssembly(asm);
            //Type t = Type.GetType(typName);
            //if (t == null)
            //{
            //    throw new Exception("Please enter valid name");
            //}
            //GetFields(t);
            //GetMethods(t);

            Console.ReadKey();
        }
        static void DispalyAssembly(Assembly a)
        {
            Console.WriteLine("Contents in Assembly");
            Console.WriteLine("Information:{0}", a.FullName);
            Type[] asm = a.GetTypes();
            foreach (Type tp in asm)
            {
                Console.WriteLine("Type:{0}", tp);
                GetFields(tp);
                GetMethods(tp);
            }
        }
        static void GetFields(Type t)
        {
            Console.WriteLine("Fields");
            FieldInfo[] fld = t.GetFields();
            foreach (FieldInfo f in fld)
            {
                Console.WriteLine("-->{0}", f.Name);                
            }
        }

        static void GetMethods(Type t)
        {
            Console.WriteLine("Methods");
            MethodInfo[] mth = t.GetMethods();
            foreach (MethodInfo m in mth)
            {
                Console.WriteLine("{0}", m.Name);
            }
        }
    }
}