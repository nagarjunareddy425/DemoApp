﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task2
{
    public class User
    {
        public int UserId { get; set; }
        public string  Name{ get; set; }
        public string  Department{ get; set; }
        public DateTime  DOJ{ get; set; }
        public long  Passcode{ get; set; }
        public int  salary{ get; set; }
    }
}
