﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Task2
{
    class UserDetails
    {
        static Random randomNumber = new Random();
        static List<User> lstUsers = new List<User>();

        static void Main(string[] args)
        {
            LoadUsers();
            DisplayUsers();
            Console.WriteLine("Please enter user details to add:");
            AddUser();
            ApplyFilters();
        }

        private static void ApplyFilters()
        {
            Console.WriteLine("Please enter dept name :");
            string searchtext = Console.ReadLine();
            List<User> filteredUsers = lstUsers.Where(x => x.Department == searchtext).ToList();
            DisplayUsers(filteredUsers);

            Console.WriteLine("List of users whose salary is > 5000: ");
            searchtext = Console.ReadLine();
            filteredUsers = lstUsers.Where(x => x.salary > 5000).ToList();
            DisplayUsers(filteredUsers);

            Console.WriteLine("Get all user whose DOJ is in last 30 days: ");
            searchtext = Console.ReadLine();
            filteredUsers = lstUsers.Where(x => x.DOJ > DateTime.Today.AddDays(-30)).ToList();
            DisplayUsers(filteredUsers);

            Console.WriteLine("Sort by name: ");
            searchtext = Console.ReadLine();
            filteredUsers = lstUsers.OrderBy(x => x.Name).ToList();
            DisplayUsers(filteredUsers);

            Console.WriteLine("Sort by DOJ in descending order : ");
            searchtext = Console.ReadLine();
            filteredUsers = lstUsers.OrderByDescending(x => x.DOJ).ToList();
            DisplayUsers(filteredUsers);
        }

        private static void DisplayUsers()
        {
            foreach (var user in lstUsers)
            {
                Console.WriteLine("User " + user.UserId + " Details are:");
                Console.WriteLine("User Name Is : " + user.Name);
                Console.WriteLine("User DOJ Is : " + user.DOJ);
                Console.WriteLine("User Department Is : " + user.Department);
                Console.WriteLine("User Passcode Is : " + user.Passcode);
                Console.WriteLine("User salary Is : " + user.salary);
                Console.WriteLine("---------------------------");
            }
            Console.ReadKey();
        }

        private static void DisplayUsers(List<User> lstUsers)
        {
            foreach (var user in lstUsers)
            {
                Console.WriteLine("User " + user.UserId + " Details are:");
                Console.WriteLine("User Name Is : " + user.Name);
                Console.WriteLine("User DOJ Is : " + user.DOJ);
                Console.WriteLine("User Department Is : " + user.Department);
                Console.WriteLine("User Passcode Is : " + user.Passcode);
                Console.WriteLine("User salary Is : " + user.salary);
                Console.WriteLine("---------------------------");
            }
            Console.ReadKey();
        }

        private static void AddUser()
        {
            var assembly = Assembly.Load("Task2");
            Type[] classes = assembly.GetTypes();
            PropertyInfo[] properties = classes[1].GetProperties();
            int count = properties.Count();
            int i = 1;
            User addUser = new User();
            addUser.UserId = randomNumber.Next(1, 100);

            while (count > 0) 
            {                
                if (properties[i].Name == "Passcode")
                {
                    addUser.Passcode = randomNumber.Next(50000, 99999);
                    count--;
                    i++;
                    continue;
                }
                Console.WriteLine("Enter User " + properties[i].Name);
                string inputString = Console.ReadLine(); 
                if (i == 1)
                {
                    while(lstUsers.Where(x => x.Name == inputString).Count() > 0)
                    {
                        Console.WriteLine("User with same name already exists. Please enter a different name:");
                        inputString = Console.ReadLine();
                    }                    
                    addUser.Name = inputString;
                }
                if (i == 2)
                {
                    addUser.Department = inputString;
                }
                if (i == 3)
                {
                    addUser.DOJ = Convert.ToDateTime(inputString);
                }
                if (i == 5)
                {
                    addUser.salary = Convert.ToInt32(inputString);
                    count = 0;
                    continue;
                }               
                count--;
                i++;
            }
            Console.WriteLine("User added successfully.!!");
            lstUsers.Add(addUser);
            DisplayUsers();
        }

        private static void LoadUsers()
        {           
            User user1 = new User();
            user1.UserId = randomNumber.Next(1,100);
            user1.Name = "User1";
            user1.Department = "Maths";
            user1.DOJ = DateTime.Today.AddDays(-40);
            user1.salary = 20000;
            user1.Passcode = randomNumber.Next(50000, 99999);
            lstUsers.Add(user1);

            User user2 = new User()
            {
                UserId = randomNumber.Next(1, 100),
                Name = "TestUser2",
                Department = "Science",
                DOJ = System.DateTime.Today,
                salary = 4000,
                Passcode= randomNumber.Next(50000, 99999)
        };
            lstUsers.Add(user2);

            lstUsers.Add(new User()
            {
                UserId = randomNumber.Next(1, 100),
                Name = "User3",
                Department = "Maths",
                DOJ = System.DateTime.Today.AddDays(-10),
                salary = 6000,
                Passcode= randomNumber.Next(50000, 99999)
        });            
        }
    }
}
