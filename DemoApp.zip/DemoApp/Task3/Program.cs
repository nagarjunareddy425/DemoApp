using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task3
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                WriteToFile();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        private static void WriteToFile()
        {
            try
            {
                var textFilePath = @"C:\Users\nag25\source\repos\DemoApp\Task3\SampleFile.txt";
                var text = File.ReadAllText(textFilePath);
                Console.WriteLine(text);

                TextWriter txt = new StreamWriter(textFilePath);
                Console.WriteLine("Please enter any string: ");
                string input = Console.ReadLine();
                if (string.IsNullOrEmpty(input))
                {
                    Console.WriteLine("Please enter any value to proceed:");
                    input = Console.ReadLine();
                }
                txt.Write(input);
                txt.Close();
                Console.WriteLine("Text file saved successfully..!!");
                Console.WriteLine("Press any key to exit.");
                Console.ReadKey();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
