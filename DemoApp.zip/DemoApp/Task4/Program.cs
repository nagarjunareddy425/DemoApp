using SharedData;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Task4
{
    class Program
    {
        static void Main(string[] args)
        {            
            Console.WriteLine("Please enter any string: ");
            string input = Console.ReadLine();
            if (string.IsNullOrEmpty(input))
            {
                Console.WriteLine("Please enter any value to proceed:");
                input = Console.ReadLine();
            }            
            var encryptedString = Encryption.Encrypt(input);
            Console.WriteLine("Encrypted String:" + encryptedString);
            Console.WriteLine("Please enter any key to see the decrypted text:");
            Console.ReadLine();
            var decryptedString = Encryption.Decrypt(encryptedString);
            Console.WriteLine("Decrypted String: " + decryptedString);

            Console.WriteLine("Please enter any string to decode: ");
            input = Console.ReadLine();
            var encodedString = Encryption.Base64Encode(input);
            Console.WriteLine("Encoded String:" + encodedString);
            Console.WriteLine("Please enter any key to see the decoded text:");
            Console.ReadLine();
            var decodedString = Encryption.Base64Decode(encodedString);
            Console.WriteLine("Decoded String: " + decodedString);
            
            Console.WriteLine("Press any key to exit.");
            Console.ReadKey();
        }
    
    }
}
