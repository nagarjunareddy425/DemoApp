﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace Task5
{
    class Serialization
    {
        static void Main(string[] args)
        {
            JSONSerialization();
            XMLSerialization();
        }

        private static void JSONSerialization()
        {
            Console.WriteLine("Please enter any key to start JSON serialization:");
            Console.ReadKey();
            string jsonData;
            User userSerializeObj = new User()
            {
                Name = "JSon",
                Description = "Serialize/Deserialize into json type"
            };
            //Serialization
            jsonData = JsonConvert.SerializeObject(userSerializeObj);
            Console.WriteLine(jsonData);

            //Deserialization
            Console.WriteLine();
            Console.WriteLine("Please enter any key to start JSON Deserialization:");
            Console.ReadKey();
            User userDeserializedObj = JsonConvert.DeserializeObject<User>(jsonData);
            Console.WriteLine("User Details Are: " + userDeserializedObj.Name + "&" + userDeserializedObj.Description);
        }

        private static void XMLSerialization()
        {
            Console.WriteLine();
            Console.WriteLine("Please enter any key to start XML serialization:");
            Console.ReadKey();
            User userSerializeObj = new User()
            {
                Name = "XML",
                Description = "Serialize/Deserialize into XML type"
            };
            //Serialization
            var serializer = new XmlSerializer(userSerializeObj.GetType());
            StringBuilder result = new StringBuilder();
            using (var writer = XmlWriter.Create("serializeClass.xml"))
            {
                serializer.Serialize(writer, userSerializeObj);
            }
            var text = File.ReadAllText("serializeClass.xml");
            Console.WriteLine(text);

            //Deserialization
            Console.WriteLine();
            Console.WriteLine("Please enter any key to start XML Deserialization:");
            Console.ReadKey();
            var deSerializer = new XmlSerializer(typeof(User));
            using (var reader = XmlReader.Create("serializeClass.xml"))
            {
                var userDeserializedObj = (User)deSerializer.Deserialize(reader);
                Console.WriteLine("User Details Are: " + userDeserializedObj.Name + "&" + userDeserializedObj.Description);
                Console.ReadKey();
            }
        }
    }
}
