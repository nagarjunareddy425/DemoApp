﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task7_CRUDWithJSON
{
    public static class JSONOperations
    {
        static string jsonFile = @"C:\Users\nag25\source\repos\DemoApp\Task7_CRUDWithJSON\customer.json";

        public static async Task GetCustomerDetails()
        {
            var json = File.ReadAllText(jsonFile);
            try
            {
                var jObject = JObject.Parse(json);

                if (jObject != null)
                {
                    Console.WriteLine("customer Details Are: ");
                    Console.WriteLine("Customer Id: " + jObject["customerid"].ToString());
                    Console.WriteLine("Customer Name: " + jObject["customername"].ToString());
                    Console.WriteLine("Customer Contact Number: " + jObject["phoneNumber"].ToString());

                    JArray ordersArrary = (JArray)jObject["orders"];
                    Console.WriteLine("Customer Orders Are: ");
                    foreach (var order in ordersArrary)
                    {
                        Console.WriteLine("       Order Id: " + order["orderid"]);
                        Console.WriteLine("       Order Name: " + order["ordername"]);
                    }
                }
                Console.WriteLine("Please enter any key to proceed: ");
                Console.ReadKey();
            }
            catch (Exception)
            {
                throw;
            }
        }

        public static async Task DeleteOrder()
        {
            var json = File.ReadAllText(jsonFile);
            Console.WriteLine("Enter order ID");
            var orderId = Convert.ToInt32(Console.ReadLine());

            try
            {
                var jObject = JObject.Parse(json);
                JArray ordersArrary = (JArray)jObject["orders"];

                if (orderId > 0)
                {
                    var orderName = string.Empty;
                    var orderToDeleted = ordersArrary.FirstOrDefault(obj => obj["orderid"].Value<int>() == orderId);

                    ordersArrary.Remove(orderToDeleted);

                    string output = Newtonsoft.Json.JsonConvert.SerializeObject(jObject, Newtonsoft.Json.Formatting.Indented);
                    File.WriteAllText(jsonFile, output);

                    Console.WriteLine("Order deleted successfully..!!");
                    await GetCustomerDetails();
                }
                else
                {
                    Console.Write("Invalid Order ID, Try Again!");
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        public static async Task UpdateOrder()
        {
            string json = File.ReadAllText(jsonFile);
            Console.WriteLine("Enter order ID");
            var orderID = Console.ReadLine();
            Console.WriteLine("Enter order Name");
            var orderName = Console.ReadLine();

            try
            {
                var jObject = JObject.Parse(json);
                JArray ordersArrary = (JArray)jObject["orders"];

                var orderId = Convert.ToInt64(orderID);

                if (orderId > 0)
                {
                    foreach (var order in ordersArrary.Where(obj => obj["orderid"].Value<int>() == orderId))
                    {
                        order["ordername"] = !string.IsNullOrEmpty(orderName) ? orderName : "";
                    }

                    jObject["orders"] = ordersArrary;
                    string output = Newtonsoft.Json.JsonConvert.SerializeObject(jObject, Newtonsoft.Json.Formatting.Indented);
                    File.WriteAllText(jsonFile, output);

                    Console.WriteLine("Order updated successfully..!!");
                    await GetCustomerDetails();
                }
                else
                {
                    Console.Write("Invalid Order ID, Try Again!");
                }
            }
            catch (Exception ex)
            {

                Console.WriteLine("Update Error : " + ex.Message.ToString());
            }
        }

        public static async Task AddOrder()
        {
            Console.WriteLine("Enter order ID");
            var orderID = Console.ReadLine();
            Console.WriteLine("Enter order Name");
            var orderName = Console.ReadLine();

            var orderDetails = "{ 'orderid': " + orderID + ",  'ordername': '" + orderName + "'}";
            try
            {
                var json = File.ReadAllText(jsonFile);
                var jsonObj = JObject.Parse(json);
                var ordersArrary = jsonObj.GetValue("orders") as JArray;
                var newOrder = JObject.Parse(orderDetails);
                ordersArrary.Add(newOrder);

                jsonObj["orders"] = ordersArrary;

                string newJsonResult = Newtonsoft.Json.JsonConvert.SerializeObject(jsonObj,
                                       Newtonsoft.Json.Formatting.Indented);
                File.WriteAllText(jsonFile, newJsonResult);

                Console.WriteLine("Order added successfully..!!");
                await GetCustomerDetails();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Add Error : " + ex.Message.ToString());
            }
        }
    }
}
