﻿using Newtonsoft.Json.Linq;
using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Task7_CRUDWithJSON
{
    class Program
    {
        

        static void Main(string[] args)
        {
            GetCustomerDetailsAsync();
            Console.WriteLine("Enter details to add order: ");
            AddOrderAsync();
            Console.WriteLine("Enter details to update order: ");
            UpdateOrderAsync();
            Console.WriteLine("Enter details to delete order: ");
            DeleteOrderAsync();
        }

        private static async void GetCustomerDetailsAsync()
        {
            await JSONOperations.GetCustomerDetails();
        }

        private static async void AddOrderAsync()
        {
            await JSONOperations.AddOrder();
        }

        private static async void UpdateOrderAsync()
        {
            await JSONOperations.UpdateOrder();
        }

        private static async void DeleteOrderAsync()
        {
            await JSONOperations.DeleteOrder();
        }

        
    }
}
