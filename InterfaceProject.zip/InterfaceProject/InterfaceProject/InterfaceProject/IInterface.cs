﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceProject
{
    interface IInterface1
    {
        void Add(int a, int b);
    }
    interface IInterface2
    {
        void Sub(int a, int b);
    }
    interface IInterface3
    {
        void Mul (int a, int b);
    }
    interface IInterface4 :IInterface1,IInterface2,IInterface3
    {
        void Div(int a, int b);
    }
    class ImplementationClass : IInterface4
    {

        public void Add(int a, int b)
        {
            Console.WriteLine(a + b);
        }
        public void Sub(int a, int b)
        {
            Console.WriteLine(a - b);
        }
        public void Mul(int a, int b)
        {
            Console.WriteLine(a * b);
        }

        public void Div(int a, int b)
        {
            Console.WriteLine(a / b);
        }

        static void Main()
        {
            ImplementationClass obj = new ImplementationClass();
            obj.Add(10, 10);
            obj.Sub(10, 10);
            obj.Mul(10, 10);
            obj.Div(10, 10);
            Console.ReadLine();
        }
    }
}
