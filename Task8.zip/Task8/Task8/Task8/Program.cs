﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task8
{
    public delegate void AddDelegate(int x, int y);
    public delegate string SayDelegate(string str);
    class Program
    {
        public void AddNumbers(int a, int b)
        {
            Console.WriteLine(a + b);
        }
        public static string SayHello(string name)
        {
            return "Hello " + name;
        }
        
        static void Main(string[] args)
        {
            Program p = new Program();
            AddDelegate ad = new AddDelegate(p.AddNumbers);
            ad.Invoke(100, 50);

            SayDelegate sd = new SayDelegate(Program.SayHello);
            string str = sd.Invoke("Nag");
           
            Console.WriteLine(str);
            Console.ReadLine();
        }
    }
}
